package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import context.DBConnect;
import model.Qualification;

public class QualificationDAO {
	// search
	public List<Qualification> search(String schoolID, String degreeID) throws Exception {
		// make a list
		List<Qualification> myList = new ArrayList<Qualification>();
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "select *, SCHOOL_NAME from QUALIFICATION inner join SCHOOL on QUALIFICATION.SCHOOL_ID = SCHOOL.SCHOOL_ID";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			// if not empty, find qualification
			if (!schoolID.isEmpty() && !degreeID.isEmpty()) {
				String school = rs.getString(17);
				String degree = rs.getString(13);
//				String schoolName = rs.getString(20);
				if (schoolID.equalsIgnoreCase(school) && degreeID.equalsIgnoreCase(degree)) {
					Qualification qlf = new Qualification(rs.getString(1), rs.getString(2), rs.getString(3),
							rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),
							rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13),
							rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17), rs.getString(18), rs.getString(19),
							rs.getString("SCHOOL_NAME"));
					myList.add(qlf);
				}
			}
		}
		stmt.close();
		return myList;
	}

	// check exist
	public boolean exist(String degreeID) throws Exception {
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "select count(*) as count from QUALIFICATION where SO_VAO_SO = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, degreeID);
		// execute query
		ResultSet rs = stmt.executeQuery();
		int count = 0;
		if (rs.next()) {
			count = rs.getInt("count");
		}
		rs.close();
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	// add qualification
	public void addQualification(Qualification qualification) throws Exception {
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "Insert into QUALIFICATION (MA_NGANH, TEN_NGANH, MA_SV, TEN_SV, NGAY_SINH, NOI_SINH, GIOI_TINH, HANG_TN, LOP, KHOA, NIEN_KHOA, QUYETDINH_TN, SO_VAO_SO, SO_HIEU_BANG, NAM_TN, LOAI_BANG, HASH_KEY, SCHOOL_ID, PREVHASH_KEY) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, qualification.getMa_nganh());
		stmt.setString(2, qualification.getTen_nganh());
		stmt.setString(3, qualification.getMa_sv());
		stmt.setString(4, qualification.getTen_sv());
		stmt.setString(5, qualification.getNgay_sinh());
		stmt.setString(6, qualification.getNoi_sinh());
		stmt.setString(7, qualification.getGioi_tinh());
		stmt.setString(8, qualification.getHang_tn());
		stmt.setString(9, qualification.getLop());
		stmt.setString(10, qualification.getKhoa());
		stmt.setString(11, qualification.getNien_khoa());
		stmt.setString(12, qualification.getQuyetdinh_TN());
		stmt.setString(13, qualification.getSovaoso());
		stmt.setString(14, qualification.getSohieubang());
		stmt.setString(15, qualification.getNam_tn());
		stmt.setString(16, qualification.getLoaibang());
		stmt.setString(17, qualification.getHashkey());
		stmt.setString(18, qualification.getSchool_ID());
		stmt.setString(19, qualification.getPrevhash());
		// execute query
		stmt.execute();
		stmt.close();
	}

	// get school name
	public String getSchoolName() throws Exception {
		String school_name = "";
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "Select SCHOOL_NAME from SCHOOL as S inner join QUALIFICATION as Q on S.SCHOOL_ID = Q.SCHOOL_ID";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			school_name = rs.getString("SCHOOL_NAME");
		}
		stmt.close();
		return school_name;

	}
}
