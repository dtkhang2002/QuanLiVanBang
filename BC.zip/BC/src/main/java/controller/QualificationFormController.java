package controller;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.QualificationDAO;
import model.Qualification;

/**
 * Servlet implementation class QualificationFormController
 */
@WebServlet("/QualificationFormController")
public class QualificationFormController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public QualificationFormController() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");// vietnamese
		try {
			// regex
			String regexNumber = "\\d+";
			String regexWord = "[a-zA-Z][a-zA-Z ]+";
			String regexDate = "\\d{4}-\\d{2}-\\d{2}";
			// create session
			HttpSession session = request.getSession(true);
			QualificationDAO q = new QualificationDAO();
			// get input value
			String manganh = request.getParameter("manganh");// 1
			String tennganh = request.getParameter("tennganh");// 2
			String masv = request.getParameter("masv");// 3
			String tensv = request.getParameter("tensv");// 4
			String ngaysinh = request.getParameter("ngaysinh");// 5
			String noisinh = request.getParameter("noisinh");// 6
			String gioitinh = request.getParameter("gioitinh");// 7
			String hangtn = request.getParameter("hangtn");// 8
			String lop = request.getParameter("lop");// 9
			String khoa = request.getParameter("khoa");// 10
			String nienkhoa = request.getParameter("nienkhoa");// 11
			String quyetdinhtn = request.getParameter("quyetdinhtn");// 12
			String sovaoso = request.getParameter("sovaoso");// 13: Khoa chinh
			String sohieubang = request.getParameter("sohieubang");// 14
			String namtn = request.getParameter("namtn");// 15
			String loaibang = request.getParameter("loaibang");// 16
			String schoolid = request.getParameter("schoolid");// 17: Khoa chinh
			//String hashkey = request.getParameter("hashkey");// 18
			String hashkey = request.getParameter("hashkey");// 18
			String prevhash = request.getParameter("prevhash"); // 19
			String schoolname = q.getSchoolName();
			
			session.setAttribute("manganh", manganh);
			session.setAttribute("tennganh", tennganh);
			session.setAttribute("masv", masv);
			session.setAttribute("tensv", tensv);
			session.setAttribute("ngaysinh", ngaysinh);
			session.setAttribute("noisinh", noisinh);
			session.setAttribute("gioitinh", gioitinh);
			session.setAttribute("lop", lop);
			session.setAttribute("khoa", khoa);
			session.setAttribute("nienkhoa", nienkhoa);
			session.setAttribute("quyetdinhtn", quyetdinhtn);
			session.setAttribute("sovaoso", sovaoso);
			session.setAttribute("sohieubang", sohieubang);
			session.setAttribute("namtn", namtn);
			session.setAttribute("loaibang", loaibang);
			session.setAttribute("schoolid", schoolid);
			session.setAttribute("hangtn", hangtn);
			session.setAttribute("hangtn", hangtn);
			session.setAttribute("loaibang", loaibang);
			
			if(request.getParameter("btnAdd") != null) {
				if (!manganh.matches(regexNumber)) {
					RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
					response.getWriter().println("<font color='red'>Mã ngành phải là số</font>");
					rd.include(request, response);
				} else if (tennganh.matches(regexNumber)) {
					RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
					response.getWriter().println("<font color='red'>Tên ngành phải là chữ</font>");
					rd.include(request, response);
				} else if (!masv.matches(regexNumber)) {
					RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
					response.getWriter().println("<font color='red'>Mã sinh viên phải là số</font>");
					rd.include(request, response);
				}
				else if (tensv.matches(regexNumber)) {
					RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
					response.getWriter().println("<font color='red'>Tên sinh viên phải là chữ</font>");
					rd.include(request, response);
				}
				else if (!ngaysinh.matches(regexDate)) {
					RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
					response.getWriter().println("<font color='red'>Ngày sinh phải ở định dạng (yyyy/mm/dd)</font>");
					rd.include(request, response);
				}
				else if (noisinh.matches(regexNumber)) {
					RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
					response.getWriter().println("<font color='red'>Nơi sinh phải là chữ</font>");
					rd.include(request, response);
				}
				
				else if (!khoa.matches(regexNumber)) {
					RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
					response.getWriter().println("<font color='red'>Khóa phải là số</font>");
					rd.include(request, response);
				}
				else if (!namtn.matches(regexNumber)) {
					RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
					response.getWriter().println("<font color='red'>Năm tốt nghiệp phải là số</font>");
					rd.include(request, response);
				}
				
				else {
					Qualification qualification = new Qualification(manganh, tennganh, masv, tensv, ngaysinh, noisinh,
							gioitinh, hangtn, lop, khoa, nienkhoa, quyetdinhtn, sovaoso, sohieubang, namtn, loaibang, prevhash,
							hashkey, schoolid, schoolname);
					if (q.exist(sovaoso)) {
						RequestDispatcher rd = request.getRequestDispatcher("/certification_form.jsp");
						response.getWriter().println("<font color='red'>Văn bằng đã tồn tại</font>");
						rd.include(request, response);
					}else {
						session.setAttribute("degree", qualification);
						q.addQualification(qualification);
						RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
						response.getWriter().println("<font color='green'>Thêm bằng thành công</font>");
						rd.forward(request, response);
					}
				}
			}
			
			if(request.getParameter("sha256") != null) {
				prevhash = toHexString(getSHA(masv + sovaoso + schoolid));
				request.setAttribute("prevhash", prevhash);
				hashkey = toHexString(getSHA(masv + sovaoso + schoolid + prevhash));
				request.setAttribute("hashkey", hashkey);
				RequestDispatcher rd = request.getRequestDispatcher("/certification_form2.jsp");
				response.getWriter().println("<font color='green'>Tạo hash thành công</font>");
				rd.include(request, response);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static byte[] getSHA(String input) throws NoSuchAlgorithmException {
		// Static getInstance method is called with hashing SHA
		MessageDigest md = MessageDigest.getInstance("SHA-256");

		// digest() method called
		// to calculate message digest of an input
		// and return array of byte
		return md.digest(input.getBytes(StandardCharsets.UTF_8));
	}

	public static String toHexString(byte[] hash) {
		// Convert byte array into signum representation
		BigInteger number = new BigInteger(1, hash);

		// Convert message digest into hex value
		StringBuilder hexString = new StringBuilder(number.toString(16));

		// Pad with leading zeros
		while (hexString.length() < 32) {
			hexString.insert(0, '0');
		}

		return hexString.toString();
	}
}
