package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.SchoolDAO;
import model.School;

/**
 * Servlet implementation class SchoolController
 */
@WebServlet("/SchoolController")
public class SchoolController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SchoolController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");// vietnamese
		// regex
		String regex = "[a-zA-Z0-9_!@#$%^&*]+";
		try {
			// get input value
			String schoolID = request.getParameter("schoolID");
			String schoolName = request.getParameter("schoolName");
			// create new SchoolDAO and session
			HttpSession session = request.getSession(true);
			SchoolDAO sc = new SchoolDAO();
			// check schoolID and schoolName regex
			if (!schoolID.matches(regex)) {
				// if not match, print error and load login page again
				RequestDispatcher rd = request.getRequestDispatcher("/school.jsp");
				response.getWriter().println("<font color='red'>Invalid schoolID or schoolName regex</font>");
				rd.include(request, response);
			} else {
				School school = new School(schoolID, schoolName);
				if (sc.exists(schoolID)) {
					RequestDispatcher rd = request.getRequestDispatcher("/school.jsp");
					response.getWriter().println("<font color='red'>School existed</font>");
					rd.include(request, response);
				} else {
					session.setAttribute("schoolSign", school);
					sc.create(school);
					RequestDispatcher rd = request.getRequestDispatcher("/admin.jsp");
					response.getWriter().println("<font color='green'>School created successfully</font>");
					rd.forward(request, response);
				}
			}
		} catch (Exception ex) {
			response.getWriter().println(ex);
		}
	}

}
