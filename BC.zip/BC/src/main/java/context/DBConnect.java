package context;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
	public Connection getConnection() throws Exception {
		String URL = "jdbc:mysql://localhost:3306/BC";
		String username = "root";
		String password = "123456";
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection(URL, username, password);
	}
}
