package model;

public class Qualification {
	private String ma_nganh;
	private String ten_nganh;
	private String ma_sv;
	private String ten_sv;
	private String ngay_sinh;
	private String noi_sinh;
	private String gioi_tinh;
	private String hang_tn;
	private String lop;
	private String khoa;
	private String nien_khoa;
	private String quyetdinh_TN;
	private String sovaoso;
	private String sohieubang;
	private String nam_tn;
	private String loaibang;
	private String prevhash;
	private String hashkey;
	private String school_ID;
	private String school_Name;
	
	// display in degree
	public Qualification(String ma_nganh, String ten_nganh, String ma_sv, String ten_sv, String ngay_sinh, String noi_sinh,
			String gioi_tinh, String hang_tn, String lop, String khoa, String nien_khoa, String quyetdinh_TN,
			String sovaoso, String sohieubang, String nam_tn, String loaibang, String prevhash, String hashkey, String school_ID, String school_Name) {
		super();
		this.ma_nganh = ma_nganh;
		this.ten_nganh = ten_nganh;
		this.ma_sv = ma_sv;
		this.ten_sv = ten_sv;
		this.ngay_sinh = ngay_sinh;
		this.noi_sinh = noi_sinh;
		this.gioi_tinh = gioi_tinh;
		this.hang_tn = hang_tn;
		this.lop = lop;
		this.khoa = khoa;
		this.nien_khoa = nien_khoa;
		this.quyetdinh_TN = quyetdinh_TN;
		this.sovaoso = sovaoso;
		this.sohieubang = sohieubang;
		this.nam_tn = nam_tn;
		this.loaibang = loaibang;
		this.prevhash = prevhash;
		this.hashkey = hashkey;
		this.school_ID = school_ID;
		this.school_Name = school_Name;
	}
	
	// input
	public Qualification(String ma_nganh, String ten_nganh, String ma_sv, String ten_sv, String ngay_sinh, String noi_sinh,
			String gioi_tinh, String hang_tn, String lop, String khoa, String nien_khoa, String quyetdinh_TN,
			String sovaoso, String sohieubang, String nam_tn, String loaibang, String prevhash, String hashkey, String school_ID) {
		super();
		this.ma_nganh = ma_nganh;
		this.ten_nganh = ten_nganh;
		this.ma_sv = ma_sv;
		this.ten_sv = ten_sv;
		this.ngay_sinh = ngay_sinh;
		this.noi_sinh = noi_sinh;
		this.gioi_tinh = gioi_tinh;
		this.hang_tn = hang_tn;
		this.lop = lop;
		this.khoa = khoa;
		this.nien_khoa = nien_khoa;
		this.quyetdinh_TN = quyetdinh_TN;
		this.sovaoso = sovaoso;
		this.sohieubang = sohieubang;
		this.nam_tn = nam_tn;
		this.loaibang = loaibang;
		this.prevhash = prevhash;
		this.hashkey = hashkey;
		this.school_ID = school_ID;
	}
	
	public Qualification(String ten_nganh, String ten_sv, String ngay_sinh, String gioi_tinh, String hang_tn,
			String nien_khoa, String quyetdinh_TN, String sovaoso, String sohieubang, String nam_tn, String loaibang,
			String school_ID, String school_Name) {
		super();
		this.ten_nganh = ten_nganh;
		this.ten_sv = ten_sv;
		this.ngay_sinh = ngay_sinh;
		this.gioi_tinh = gioi_tinh;
		this.hang_tn = hang_tn;
		this.nien_khoa = nien_khoa;
		this.quyetdinh_TN = quyetdinh_TN;
		this.sovaoso = sovaoso;
		this.sohieubang = sohieubang;
		this.nam_tn = nam_tn;
		this.loaibang = loaibang;
		this.school_ID = school_ID;
		this.school_Name = school_Name;
	}

	public String getMa_nganh() {
		return ma_nganh;
	}

	public void setMa_nganh(String ma_nganh) {
		this.ma_nganh = ma_nganh;
	}

	public String getTen_nganh() {
		return ten_nganh;
	}

	public void setTen_nganh(String ten_nganh) {
		this.ten_nganh = ten_nganh;
	}

	public String getMa_sv() {
		return ma_sv;
	}

	public void setMa_sv(String ma_sv) {
		this.ma_sv = ma_sv;
	}

	public String getTen_sv() {
		return ten_sv;
	}

	public void setTen_sv(String ten_sv) {
		this.ten_sv = ten_sv;
	}

	public String getNgay_sinh() {
		return ngay_sinh;
	}

	public void setNgay_sinh(String ngay_sinh) {
		this.ngay_sinh = ngay_sinh;
	}

	public String getNoi_sinh() {
		return noi_sinh;
	}

	public void setNoi_sinh(String noi_sinh) {
		this.noi_sinh = noi_sinh;
	}

	public String getGioi_tinh() {
		return gioi_tinh;
	}

	public void setGioi_tinh(String gioi_tinh) {
		this.gioi_tinh = gioi_tinh;
	}

	public String getHang_tn() {
		return hang_tn;
	}

	public void setHang_tn(String hang_tn) {
		this.hang_tn = hang_tn;
	}

	public String getLop() {
		return lop;
	}

	public void setLop(String lop) {
		this.lop = lop;
	}

	public String getKhoa() {
		return khoa;
	}

	public void setKhoa(String khoa) {
		this.khoa = khoa;
	}

	public String getNien_khoa() {
		return nien_khoa;
	}

	public void setNien_khoa(String nien_khoa) {
		this.nien_khoa = nien_khoa;
	}

	public String getQuyetdinh_TN() {
		return quyetdinh_TN;
	}

	public void setQuyetdinh_TN(String quyetdinh_TN) {
		this.quyetdinh_TN = quyetdinh_TN;
	}

	public String getSovaoso() {
		return sovaoso;
	}

	public void setSovaoso(String sovaoso) {
		this.sovaoso = sovaoso;
	}

	public String getSohieubang() {
		return sohieubang;
	}

	public void setSohieubang(String sohieubang) {
		this.sohieubang = sohieubang;
	}

	public String getNam_tn() {
		return nam_tn;
	}

	public void setNam_tn(String nam_tn) {
		this.nam_tn = nam_tn;
	}

	public String getLoaibang() {
		return loaibang;
	}

	public void setLoaibang(String loaibang) {
		this.loaibang = loaibang;
	}

	public String getHashkey() {
		return hashkey;
	}

	public void setHashkey(String hashkey) {
		this.hashkey = hashkey;
	}

	public String getSchool_ID() {
		return school_ID;
	}

	public void setSchool_ID(String school_ID) {
		this.school_ID = school_ID;
	}

	public String getSchool_Name() {
		return school_Name;
	}

	public void setSchool_Name(String school_Name) {
		this.school_Name = school_Name;
	}

	public String getPrevhash() {
		return prevhash;
	}

	public void setPrevhash(String prevhash) {
		this.prevhash = prevhash;
	}
	
	
	
}
