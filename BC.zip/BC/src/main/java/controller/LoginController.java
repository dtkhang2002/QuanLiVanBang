package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AccountDAO;
import model.Account;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("login.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8"); // vietnamese
		// regex
		String regexMail = "^[A-Z0-9_a-z]+@[A-Z0-9\\.a-z]+\\.[A-Za-z]{2,6}$";
		String regex = "[a-zA-Z0-9_!@#$%^&*]+";
		// collect the data from the form
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		// create session
		HttpSession session = request.getSession(true);
		// validate form
		if (!email.matches(regexMail) || !password.matches(regex)) {
			RequestDispatcher rd1 = request.getRequestDispatcher("/login.jsp");
			out.println("<font color = 'red'>Invalid email or password.</font>");
			rd1.include(request, response);
		} else {
			// login function
			AccountDAO ac = new AccountDAO();
			try {
				String schoolID = ac.getSchoolID(email);
				String name = ac.getName(email);
				// set attribute for account
				if (ac.login(email, password) == true) {
					// create a particularly session
					if (session.getAttribute("account") == null) {
						session.setAttribute("account", new Account(email, password, schoolID, name));
					}
					// check role to change
					if (!ac.checkRole(email)) {
						RequestDispatcher rd1 = request.getRequestDispatcher("/index.jsp");
						rd1.forward(request, response);
					} else {
						RequestDispatcher rd1 = request.getRequestDispatcher("/admin.jsp");
						rd1.forward(request, response);
					}
				} else {
					RequestDispatcher rd1 = request.getRequestDispatcher("/login.jsp");
					out.println("<font color='red'>Email and password are not matched or not existed</font>");
					rd1.include(request, response);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
