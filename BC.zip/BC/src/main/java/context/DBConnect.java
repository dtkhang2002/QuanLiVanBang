package context;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
	public Connection getConnection() throws Exception {
		String DB_URL = "jdbc:sqlserver://localhost:1433;" + "databaseName=BC;" + "intergratedSecurity=true";
		String username = "user3";
		String password = "1234567890";
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		return DriverManager.getConnection(DB_URL, username, password);
	}
}
