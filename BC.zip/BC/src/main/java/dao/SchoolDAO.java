package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import context.DBConnect;
import model.School;

public class SchoolDAO {
	// check if school existed in the database or not
	public boolean exists(String schoolID) throws Exception {
		// connect to the Database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "select count(*) as count from SCHOOL where SCHOOL_ID = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, schoolID);
		// execute query
		ResultSet rs = stmt.executeQuery();
		int count = 0;
		if (rs.next()) {
			count = rs.getInt("count");
		}
		rs.close();
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	// create school
	public void create(School school) throws Exception {
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "insert into SCHOOL (SCHOOL_ID, SCHOOL_NAME) values(?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, school.getSchool_ID());
		stmt.setString(2, school.getName());

		stmt.execute();
		stmt.close();
	}

	// get all the school in the db for admin
	public List<School> getSchoolAdmin() throws Exception{
		// make a list to store all the account
		List<School> listSc = new ArrayList<School>();
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from SCHOOL";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			listSc.add(new School(rs.getString(1), rs.getString(2)));
		}
		stmt.close();
		return listSc;
	}
}
