﻿/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [MA_NGANH] -- 1, int
      ,[TEN_NGANH] -- 2, string
      ,[MA_SV] -- 3, int
      ,[TEN_SV] -- 4, string
      ,[NGAY_SINH] -- 5, string
      ,[NOI_SINH] -- 6 string
      ,[GIOI_TINH] -- 7 string
      ,[HANG_TN] -- 8 string
      ,[LOP] -- 9 string
      ,[KHOA] -- 10 int
      ,[NIEN_KHOA] -- 11 string
      ,[QUYETDINH_TN] -- 12 string
      ,[SO_VAO_SO] --13 string
      ,[SO_HIEU_BANG] -- 14 string
      ,[NAM_TN] -- 15 int
      ,[LOAI_BANG] -- 16 string
      ,[HASH_KEY] -- 17 string
      ,[SCHOOL_ID] -- 18 string
  FROM [BC].[dbo].[QUALIFICATION]

  INSERT INTO QUALIFICATION VALUES 
(7480201, 'Công nghệ thông tin', 1300791, 'Đỗ Văn Chanh', '1995-07-07', 'Vĩnh Phúc', 'Nam', 
'Khá', 'Công nghệ thông tin 1 K54', 54, '2013-2018', 
'1843/QĐ-ĐHGTVT ngày 09/11/2020', '435/K54', '532508', 
2020, 'CU NHAN', '9be5eaafd1f38e2a080a9c11daeac6d29828541a178531e58fa4ead36beb4b52', 'FPT')