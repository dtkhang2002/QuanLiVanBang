package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import context.DBConnect;
import model.Account;

public class AccountDAO {
	public boolean login(String email, String password) throws Exception {
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "Select count(*) as count from ACCOUNT where ACCOUNT_EMAIL=? and ACCOUNT_PASSWORD=?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, email);
		stmt.setString(2, password);
		// execute query
		ResultSet rs = stmt.executeQuery();
		int count = 0;
		if (rs.next()) {
			count = rs.getInt("count");
		}
		rs.close();
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	// check role while logging in (0: administrator, 1: teacher)
	public boolean checkRole(String email) throws Exception {
		boolean ok = false;
		// connect to database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "Select * from ACCOUNT";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			// get email
			String remail = rs.getString(1);
			// check role
			if (remail.equalsIgnoreCase(email) && rs.getInt(4) == 0) {
				ok = true;
			}
		}
		stmt.close();
		return ok;
	}

	// check if the account existed in the database or not
	public boolean exists(String email) throws Exception {
		// connect to the Database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "select count(*) as count from ACCOUNT where ACCOUNT_EMAIL = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, email);
		// execute query
		ResultSet rs = stmt.executeQuery();
		int count = 0;
		if (rs.next()) {
			count = rs.getInt("count");
		}
		rs.close();
		if (count == 0) {
			return false;
		} else {
			return true;
		}
	}

	// sign up
	public void signup(Account account) throws Exception {
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "insert into ACCOUNT (ACCOUNT_EMAIL, ACCOUNT_PASSWORD, ACCOUNT_NAME, ACCOUNT_ROLE, SCHOOL_ID) values(?,?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, account.getEmail());
		stmt.setString(2, account.getPassword());
		stmt.setString(3, account.getName());
		stmt.setInt(4, account.getRole());
		stmt.setString(5, account.getSchool_ID());
		stmt.execute();
		stmt.close();
	}

	// get all the account in the db for admin
	public List<Account> getAccountAdmin() throws Exception {
		// make a list to store all the account
		List<Account> listAcc = new ArrayList<Account>();
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "select * from ACCOUNT";
		PreparedStatement stmt = con.prepareStatement(sql);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			listAcc.add(new Account(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5)));
		}
		stmt.close();
		return listAcc;
	}

	// get schoolID
	public String getSchoolID(String email) throws Exception {
		String school_ID = "";
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "Select SCHOOL_ID from ACCOUNT where ACCOUNT_EMAIL=?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, email);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			school_ID = rs.getString("SCHOOL_ID");
		}
		stmt.close();
		return school_ID;
	}
	// get name
	public String getName(String email) throws Exception{
		String name = "";
		// connect to the database
		DBConnect db = new DBConnect();
		Connection con = db.getConnection();
		// sql query
		String sql = "Select ACCOUNT_NAME from ACCOUNT where ACCOUNT_EMAIL = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, email);
		// execute query
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			name = rs.getString("ACCOUNT_NAME");
		}
		stmt.close();
		return name;
	}
}
