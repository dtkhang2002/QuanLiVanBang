package model;

public class Account {
	private String email;
	private String name;
	private String password;
	private int role;
	private String school_ID;
	
	public Account(String email, String password, String name, int role, String school_ID) {
		super();
		this.email = email;
		this.password = password;
		this.name = name;
		this.role = role;
		this.school_ID = school_ID;
	}
	
	public Account(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	public Account(String email, String password, String school_ID, String name) {
		super();
		this.email = email;
		this.password = password;
		this.school_ID = school_ID;
		this.name = name;
	}
	
	public Account() {
		super();
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public String getSchool_ID() {
		return school_ID;
	}

	public void setSchool_ID(String school_ID) {
		this.school_ID = school_ID;
	}
	
	
	
}
