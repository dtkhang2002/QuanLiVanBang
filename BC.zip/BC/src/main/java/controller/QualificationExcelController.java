package controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import context.DBConnect;

/**
 * Servlet implementation class QualificationExcelController
 */
@WebServlet("/QualificationExcelController")
public class QualificationExcelController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QualificationExcelController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DBConnect db = new DBConnect();
		Connection con = null;
		PrintWriter out = response.getWriter();
		try {
			con = db.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String filename = request.getParameter("filename");
		int batchSize = 20;
		try {
			FileInputStream inputStream = new FileInputStream(filename);
			Workbook workbook = new XSSFWorkbook(inputStream);
			
			Sheet firstSheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = firstSheet.iterator();
            
            String sql = "Insert into QUALIFICATION values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = con.prepareStatement(sql);    
            int count = 0;
            
            rowIterator.next(); // skip the header row
            while (rowIterator.hasNext()) {
                Row nextRow = rowIterator.next();
                Iterator<Cell> cellIterator = nextRow.cellIterator();
 
                while (cellIterator.hasNext()) {
                    Cell nextCell = cellIterator.next();
 
                    int columnIndex = nextCell.getColumnIndex();
 
                    switch (columnIndex) {
                    case 0:
                        int manganh = (int) nextCell.getNumericCellValue();
                        statement.setInt(1, manganh);
                        break;
                    case 1:
                    	String tennganh = nextCell.getStringCellValue();
                        statement.setString(2, tennganh);
                        break;
                    case 2:
                    	int masv = (int) nextCell.getNumericCellValue();
                    	statement.setInt(3, masv);
                        break;
                    case 3:
                    	String tensv = nextCell.getStringCellValue();
                    	statement.setString(4, tensv);
                        break;
                    case 4:
                    	DataFormatter dataFormatter = new DataFormatter();
                    	String ngaysinh = dataFormatter.formatCellValue(nextCell);
                    	statement.setString(5, ngaysinh);
                        break;
                    case 5:
                    	String noisinh = nextCell.getStringCellValue();
                    	statement.setString(6, noisinh);
                        break;
                    case 6:
                    	String gioitinh = nextCell.getStringCellValue();
                    	statement.setString(7, gioitinh);
                        break;
                    case 7:
                    	String hangtn = nextCell.getStringCellValue();
                    	statement.setString(8, hangtn);
                        break;
                    case 8:
                    	String lop = nextCell.getStringCellValue();
                    	statement.setString(9, lop);
                        break;
                    case 9:
                    	int khoa = (int) nextCell.getNumericCellValue();
                    	statement.setInt(10, khoa);
                        break;
                    case 10:
                    	String nienkhoa = nextCell.getStringCellValue();
                    	statement.setString(11, nienkhoa);
                        break;
                    case 11:
                    	String quyetdinhtn = nextCell.getStringCellValue();
                    	statement.setString(12, quyetdinhtn);
                        break;
                    case 12:
                    	String sovaoso = nextCell.getStringCellValue();
                    	statement.setString(13, sovaoso);
                        break;
                    case 13:
                    	String sohieubang = nextCell.getStringCellValue();
                    	statement.setString(14, sohieubang);
                        break;
                    case 14:
                    	int namtn = (int) nextCell.getNumericCellValue();
                    	statement.setInt(15, namtn);
                        break;
                    case 15:
                    	String loaibang = nextCell.getStringCellValue();
                    	statement.setString(16, loaibang);
                        break;
                    case 16:
                    	String hashkey = nextCell.getStringCellValue();
                    	statement.setString(17, hashkey);
                        break;
                    case 17:
                    	String school_id = nextCell.getStringCellValue();
                    	statement.setString(18, school_id);
                        break;
                    case 18:
                    	String prevhash = nextCell.getStringCellValue();
                    	statement.setString(19, prevhash);
                    	break;
                     default:
                    	 break;
                    }
 
                }
                 
                statement.addBatch();
                 
                if (count % batchSize == 0) {
                    statement.executeBatch();
                }              
 
            }
            
            workbook.close();
            
            // execute the remaining queries
            statement.executeBatch();
  
            con.commit();
            con.close();
            RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
            rd.forward(request, response);
		}catch (IOException ex1) {
			RequestDispatcher rd = request.getRequestDispatcher("/certification_excel.jsp");
			out.print("Error file");
            rd.include(request, response);
        } catch (SQLException ex2) {
        	RequestDispatcher rd = request.getRequestDispatcher("/certification_excel.jsp");
			out.print("Error database");
            rd.include(request, response);
            ex2.printStackTrace();
        }
	}

}
