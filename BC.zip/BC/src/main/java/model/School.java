package model;

public class School {
	private String school_ID;
	private String name;
	
	public School(String school_ID, String name) {
		super();
		this.school_ID = school_ID;
		this.name = name;
	}
	
	public School(String school_ID) {
		super();
		this.school_ID = school_ID;
	}

	public String getSchool_ID() {
		return school_ID;
	}

	public void setSchool_ID(String school_ID) {
		this.school_ID = school_ID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
